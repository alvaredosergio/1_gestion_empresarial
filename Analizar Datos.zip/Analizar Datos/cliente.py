class Cliente:
    def __init__(self, id, nombre, meses, region):
        self.id=id
        self.nombre=nombre
        self.meses=meses
        self.region=region