from Estudiante import Estudiante

e1 = Estudiante("Sergio", 18, 5, 4, 6, 8)
e2 = Estudiante("Maria", 19, 8, 7, 10, 5)
e3 = Estudiante("Jorge", 17, 3, 8, 5, 6)
e4 = Estudiante("Raul", 21, 5, 3, 6, 7)
e5 = Estudiante("Paco", 22, 7, 6, 7, 8)
e6 = Estudiante("Julian", 17, 8, 5, 3, 3)
e7 = Estudiante("Rosa", 15, 7, 9, 5, 5)
e8 = Estudiante("Veronica", 22, 9, 3, 9, 5)
e9 = Estudiante("Paquito", 21, 3, 5, 3, 2)
e10 = Estudiante("Isaac", 20, 2, 6, 9, 9)

grupo = []
grupo.append(e1)
grupo.append(e2)
grupo.append(e3)
grupo.append(e4)
grupo.append(e5)
grupo.append(e6)
grupo.append(e7)
grupo.append(e8)
grupo.append(e9)
grupo.append(e10)






